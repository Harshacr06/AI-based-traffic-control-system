# VisionFlow - FIXED VERSION - Part 1
# Key Fixes:
# 1. Proper timer calculations for both VAC and AWT
# 2. Immediate red signal when lane reaches 0 vehicles
# 3. Faster AWT switching without unnecessary delays
# 4. Better waiting time boost calculations

from flask import Flask, render_template, jsonify, request, Response
from flask_socketio import SocketIO
from flask_cors import CORS
import cv2
from ultralytics import YOLO
import numpy as np
import time
from datetime import datetime
import threading
import logging
import os
from werkzeug.utils import secure_filename
from collections import deque

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'visionflow_dual_algorithm_2025'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp'}

CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


class Vehicle:
    """Individual vehicle with waiting time tracking"""
    def __init__(self, vehicle_id, lane, arrival_time):
        self.id = vehicle_id
        self.lane = lane
        self.arrival_time = arrival_time
        self.waiting_time = 0
        self.paused_waiting_time = 0
    
    def update_waiting_time(self, current_time):
        """Update waiting time based on current time"""
        self.waiting_time = (current_time - self.arrival_time) + self.paused_waiting_time
        return self.waiting_time
    
    def pause(self, current_time):
        """Pause the waiting time accumulation"""
        self.paused_waiting_time = (current_time - self.arrival_time) + self.paused_waiting_time
        self.arrival_time = current_time
    
    def resume(self, current_time):
        """Resume waiting time from where it was paused"""
        self.arrival_time = current_time


class VACAlgorithm:
    """Traditional Vehicle Actuated Control - Count Based Only - FIXED"""
    
    def __init__(self):
        self.seconds_per_vehicle = 3
        self.min_green_time = 10
        self.max_green_time = 60
        self.emergency_threshold = 18
        
        logger.info("✅ VAC (Vehicle Actuated Control) Algorithm initialized")
        logger.info("   📊 Pure vehicle count based optimization")
    
    def calculate_priority_score(self, vehicle_count, avg_waiting_time, is_first_cycle=False):
        """VAC uses ONLY vehicle count (ignores waiting time)"""
        normalized_count = min(vehicle_count / 20.0, 1.0)
        return normalized_count
    
    def calculate_green_time(self, vehicle_count, avg_waiting_time=0, has_ambulance=False, upstream_surge=False):
        """Calculate green time based purely on vehicle count - FIXED"""
        rules = []
        
        if has_ambulance:
            time_needed = max(20, min(vehicle_count * 3, 60))
            return (time_needed, [f'🚑 AMBULANCE: {time_needed}s'], '🚑 AMBULANCE')
        
        if upstream_surge:
            time_needed = max(30, min(vehicle_count * 3, 60))
            return (time_needed, [f'🔗 UPSTREAM SURGE: {time_needed}s'], '🔗 UPSTREAM')
        
        # FIXED: Return 0 for empty lanes
        if vehicle_count == 0:
            return (0, ['🚫 Empty: 0 vehicles'], '🚫 SKIP')
        
        if vehicle_count >= self.emergency_threshold:
            return (
                self.max_green_time,
                [f'🚨 EMERGENCY: {vehicle_count}v ≥ 18v → 60s'],
                '🚨 EMERGENCY'
            )
        
        # FIXED: Clear calculation
        base_time = vehicle_count * self.seconds_per_vehicle
        final = max(self.min_green_time, min(base_time, self.max_green_time))
        
        rules.append(f"VAC: {vehicle_count}v × 3s = {base_time}s → {final}s")
        
        if vehicle_count >= 15:
            priority = "🔴 HIGH"
        elif vehicle_count >= 8:
            priority = "🟡 MEDIUM"
        else:
            priority = "🟢 LOW"
        
        return final, rules, priority


class AWTAlgorithm:
    """Adaptive Waiting Time - Advanced Algorithm - OPTIMIZED"""
    
    def __init__(self):
        self.green_threshold = 20
        self.yellow_threshold = 40
        self.dull_red_threshold = 60
        
        # OPTIMIZED: Better weight distribution
        self.initial_waiting_time_weight = 0.50  # Changed from 0.60
        self.initial_vehicle_count_weight = 0.50  # Changed from 0.40
        
        self.ongoing_waiting_time_weight = 0.75  # Changed from 0.85
        self.ongoing_vehicle_count_weight = 0.25  # Changed from 0.15
        
        self.seconds_per_vehicle = 3
        self.min_green_time = 10
        self.max_green_time = 60
        self.emergency_threshold = 18
        
        self.critical_wait_time = 60
        self.high_wait_time = 40
        self.medium_wait_time = 20
        
        logger.info("✅ AWT (Adaptive Waiting Time) Algorithm initialized - OPTIMIZED")
        logger.info(f"   🔄 Initial: {self.initial_waiting_time_weight*100}% wait + {self.initial_vehicle_count_weight*100}% count")
        logger.info(f"   ⏰ Ongoing: {self.ongoing_waiting_time_weight*100}% wait + {self.ongoing_vehicle_count_weight*100}% count")
    
    def get_heatmap_color(self, waiting_time):
        """Get heatmap color based on waiting time"""
        if waiting_time >= self.critical_wait_time:
            return '#ef4444', 'RED'
        elif waiting_time >= self.dull_red_threshold:
            return '#fb923c', 'DULL_RED'
        elif waiting_time >= self.yellow_threshold:
            return '#fbbf24', 'YELLOW'
        elif waiting_time >= self.green_threshold:
            return '#a3e635', 'LIGHT_GREEN'
        else:
            return '#22c55e', 'GREEN'
    
    def get_urgency_level(self, avg_waiting_time):
        """Get urgency level (0.0 - 1.0) based on waiting time"""
        if avg_waiting_time >= self.critical_wait_time:
            return min(1.0, avg_waiting_time / 100.0)
        else:
            return avg_waiting_time / self.critical_wait_time
    
    def calculate_priority_score(self, vehicle_count, avg_waiting_time, is_first_cycle=False):
        """AWT uses BOTH waiting time and vehicle count with adaptive weighting"""
        normalized_wait = min(avg_waiting_time / 100.0, 1.0)
        normalized_count = min(vehicle_count / 20.0, 1.0)
        
        if is_first_cycle:
            wait_weight = self.initial_waiting_time_weight
            count_weight = self.initial_vehicle_count_weight
        else:
            wait_weight = self.ongoing_waiting_time_weight
            count_weight = self.ongoing_vehicle_count_weight
        
        score = (normalized_wait * wait_weight) + (normalized_count * count_weight)
        return score
    
    def calculate_green_time(self, vehicle_count, avg_waiting_time, has_ambulance=False, upstream_surge=False):
        """Calculate optimal green time considering waiting time - OPTIMIZED"""
        rules = []
        
        if has_ambulance:
            time_needed = max(20, min(vehicle_count * 3, 60))
            return (time_needed, [f'🚑 AMBULANCE: {time_needed}s'], '🚑 AMBULANCE')
        
        if upstream_surge:
            time_needed = max(30, min(vehicle_count * 3, 60))
            return (time_needed, [f'🔗 UPSTREAM SURGE: {time_needed}s'], '🔗 UPSTREAM')
        
        # FIXED: Return 0 for empty lanes
        if vehicle_count == 0:
            return (0, ['🚫 Empty: 0 vehicles'], '🚫 SKIP')
        
        if vehicle_count >= self.emergency_threshold:
            return (
                self.max_green_time,
                [f'🚨 EMERGENCY: {vehicle_count}v ≥ 18v → 60s'],
                '🚨 EMERGENCY'
            )
        
        # Base time from vehicle count
        base = vehicle_count * self.seconds_per_vehicle
        
        # OPTIMIZED: More aggressive waiting time boosts
        if avg_waiting_time >= self.critical_wait_time:
            boost = 20  # Increased from 15
            rules.append(f"🔴 Critical Wait (≥60s): +{boost}s boost")
        elif avg_waiting_time >= self.high_wait_time:
            boost = 12  # Increased from 10
            rules.append(f"🟠 High Wait (≥40s): +{boost}s boost")
        elif avg_waiting_time >= self.medium_wait_time:
            boost = 7  # Increased from 5
            rules.append(f"🟡 Medium Wait (≥20s): +{boost}s boost")
        else:
            boost = 0
        
        # Calculate final time
        final = max(self.min_green_time, min(base + boost, self.max_green_time))
        rules.insert(0, f"Base: {vehicle_count}v × 3s = {base}s + {boost}s wait → {final}s")
        
        # Determine priority
        if avg_waiting_time >= self.critical_wait_time:
            priority = "🔴 CRITICAL"
        elif avg_waiting_time >= self.high_wait_time:
            priority = "🟠 HIGH"
        elif vehicle_count >= 15:
            priority = "🔴 HIGH"
        elif vehicle_count >= 8 or avg_waiting_time >= self.medium_wait_time:
            priority = "🟡 MEDIUM"
        else:
            priority = "🟢 LOW"
        
        return final, rules, priority


class PriorityTrafficSystem:
    """Dual Algorithm Traffic Control System - OPTIMIZED"""
    
    def __init__(self):
        logger.info("="*70)
        logger.info("🚦 VisionFlow Traffic Control System v5.1 - FIXED")
        logger.info("="*70)
        logger.info(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"👤 User: Akashy630")
        logger.info("="*70)
        
        self.lock = threading.Lock()
        self.is_running = False
        
        self.use_awt_algorithm = True
        self.vac_algorithm = VACAlgorithm()
        self.awt_algorithm = AWTAlgorithm()
        self.is_first_cycle = True
        
        self.camera_north = None
        self.current_frame_north = None
        self.current_frame_east_upstream = None
        self.uploaded_image_path = None
        
        self.upstream_surge_detected_time = None
        self.upstream_surge_countdown = 0
        
        try:
            self.model = YOLO('yolov8n.pt', verbose=False)
            self.vehicle_classes = ['car', 'motorcycle', 'bus', 'truck']
            logger.info("✅ YOLO loaded")
        except Exception as e:
            self.model = None
            logger.warning(f"⚠️ YOLO not available: {e}")
        
        self.vehicle_queues = {
            'north': deque(),
            'south': deque(),
            'east': deque(),
            'west': deque()
        }
        self.next_vehicle_id = 0
        
        self.lanes = {
            'north': {
                'vehicles': 0,
                'speed': 0,
                'signal': 'RED',
                'timer': 0,
                'last_clear': 0,
                'has_ambulance': False,
                'avg_waiting_time': 0,
                'max_waiting_time': 0,
                'urgency': 0.0,
                'heatmap_color': '#22c55e',
                'heatmap_label': 'GREEN'
            },
            'south': {
                'vehicles': 5,
                'speed': 50,
                'signal': 'RED',
                'timer': 0,
                'last_clear': 0,
                'has_ambulance': False,
                'avg_waiting_time': 0,
                'max_waiting_time': 0,
                'urgency': 0.0,
                'heatmap_color': '#22c55e',
                'heatmap_label': 'GREEN'
            },
            'east': {
                'vehicles': 3,
                'speed': 60,
                'signal': 'RED',
                'timer': 0,
                'last_clear': 0,
                'has_ambulance': False,
                'upstream_vehicles': 0,
                'avg_waiting_time': 0,
                'max_waiting_time': 0,
                'urgency': 0.0,
                'heatmap_color': '#22c55e',
                'heatmap_label': 'GREEN'
            },
            'west': {
                'vehicles': 12,
                'speed': 40,
                'signal': 'RED',
                'timer': 0,
                'last_clear': 0,
                'has_ambulance': False,
                'avg_waiting_time': 0,
                'max_waiting_time': 0,
                'urgency': 0.0,
                'heatmap_color': '#22c55e',
                'heatmap_label': 'GREEN'
            }
        }
        
        current_time = time.time()
        for lane_name, lane_data in self.lanes.items():
            for i in range(lane_data['vehicles']):
                vehicle = Vehicle(self.next_vehicle_id, lane_name, current_time)
                self.vehicle_queues[lane_name].append(vehicle)
                self.next_vehicle_id += 1
        
        self.current_green_lane = None
        self.in_yellow_phase = False
        self.yellow_countdown = 0
        self.last_served_lane = None
        self._pending_ambulance_lane = None
        self._pending_upstream_surge = False
        
        self.cycles_since_service = {
            'north': 0,
            'south': 0,
            'east': 0,
            'west': 0
        }
        self.starvation_threshold = 4
        
        self.last_user_update = {}
        
        self.statistics = {
            'total_vehicles_processed': 0,
            'vehicles_cleared': 0,
            'avg_wait_time': 0,
            'system_efficiency': 75,
            'ambulance_activations': 0,
            'emergency_activations': 0,
            'upstream_surge_activations': 0,
            'anti_starvation_activations': 0,
            'waiting_time_priorities': 0,
            'cycles_completed': 0,
            'total_waiting_time': 0,
            'max_waiting_time_ever': 0,
            'waiting_time_variance': 0,
            'vac_avg_wait_time': 0,
            'vac_max_wait_time': 0,
            'vac_total_wait_time': 0,
            'vac_vehicles_cleared': 0,
            'vac_cycles': 0,
            'awt_avg_wait_time': 0,
            'awt_max_wait_time': 0,
            'awt_total_wait_time': 0,
            'awt_vehicles_cleared': 0,
            'awt_cycles': 0,
            'wait_time_improvement': 0,
            'max_wait_improvement': 0,
            'fairness_improvement': 0
        }
        
        self.signal_logic = {
            'decision': 'Initializing...',
            'action': 'Starting up...',
            'priority': 'System startup',
            'reason': 'Upload image for upstream detection',
            'rules_applied': [],
            'algorithm_used': 'AWT'
        }
        
        self._switch_to_highest_priority_lane()
        
        logger.info("✅ System initialized - OPTIMIZED VERSION")
        logger.info("="*70)
    # CONTINUATION OF PriorityTrafficSystem class from Part 1
    
    def toggle_algorithm(self):
        """Toggle between VAC and AWT algorithms"""
        with self.lock:
            self.use_awt_algorithm = not self.use_awt_algorithm
            algo_name = "AWT (Adaptive Waiting Time)" if self.use_awt_algorithm else "VAC (Vehicle Actuated Control)"
            logger.info(f"🔄 Switched to {algo_name}")
            return self.use_awt_algorithm
    
    def _add_vehicle_to_queue(self, lane_name):
        """Add a new vehicle to the queue"""
        current_time = time.time()
        vehicle = Vehicle(self.next_vehicle_id, lane_name, current_time)
        self.vehicle_queues[lane_name].append(vehicle)
        self.next_vehicle_id += 1
        self.lanes[lane_name]['vehicles'] = len(self.vehicle_queues[lane_name])
    
    def _remove_vehicle_from_queue(self, lane_name):
        """Remove a vehicle from the queue (cleared)"""
        if len(self.vehicle_queues[lane_name]) > 0:
            vehicle = self.vehicle_queues[lane_name].popleft()
            self.lanes[lane_name]['vehicles'] = len(self.vehicle_queues[lane_name])
            return vehicle
        return None
    
    def _update_waiting_times(self, lane_name):
        """Update waiting times for all vehicles in a lane"""
        current_time = time.time()
        queue = self.vehicle_queues[lane_name]
        
        if len(queue) == 0:
            self.lanes[lane_name]['avg_waiting_time'] = 0
            self.lanes[lane_name]['max_waiting_time'] = 0
            self.lanes[lane_name]['urgency'] = 0.0
            self.lanes[lane_name]['heatmap_color'] = '#22c55e'
            self.lanes[lane_name]['heatmap_label'] = 'GREEN'
            return
        
        waiting_times = []
        for vehicle in queue:
            wait = vehicle.update_waiting_time(current_time)
            waiting_times.append(wait)
        
        avg_wait = np.mean(waiting_times)
        max_wait = np.max(waiting_times)
        
        self.lanes[lane_name]['avg_waiting_time'] = round(avg_wait, 1)
        self.lanes[lane_name]['max_waiting_time'] = round(max_wait, 1)
        
        if self.use_awt_algorithm:
            self.lanes[lane_name]['urgency'] = round(self.awt_algorithm.get_urgency_level(avg_wait), 2)
            color, label = self.awt_algorithm.get_heatmap_color(avg_wait)
            self.lanes[lane_name]['heatmap_color'] = color
            self.lanes[lane_name]['heatmap_label'] = label
        else:
            self.lanes[lane_name]['urgency'] = 0.0
            self.lanes[lane_name]['heatmap_color'] = '#3b82f6'
            self.lanes[lane_name]['heatmap_label'] = 'VAC'
        
        if max_wait > self.statistics['max_waiting_time_ever']:
            self.statistics['max_waiting_time_ever'] = round(max_wait, 1)
    
    def start(self):
        if self.is_running:
            return False
        self.is_running = True
        
        logger.info("▶️ Starting system...")
        current_time = time.time()
        
        with self.lock:
            for lane_name, queue in self.vehicle_queues.items():
                for vehicle in queue:
                    vehicle.resume(current_time)
            
            for lane_name in self.lanes.keys():
                self._update_waiting_times(lane_name)
        
        logger.info("✅ System started")
        
        threading.Thread(target=self._camera_north_loop, daemon=True).start()
        threading.Thread(target=self._image_analysis_loop, daemon=True).start()
        threading.Thread(target=self._control_loop, daemon=True).start()
        threading.Thread(target=self._broadcast_loop, daemon=True).start()
        threading.Thread(target=self._waiting_time_update_loop, daemon=True).start()
        
        return True
    
    def stop(self):
        logger.info("⏹️ Stopping...")
        self.is_running = False
        
        if self.camera_north:
            self.camera_north.release()
        
        logger.info("⏸️ Pausing waiting time accumulation...")
        current_time = time.time()
        
        with self.lock:
            for lane_name, queue in self.vehicle_queues.items():
                for vehicle in queue:
                    vehicle.pause(current_time)
        
        logger.info("✅ System stopped")
        return True
    
    def _waiting_time_update_loop(self):
        """Continuously update waiting times"""
        logger.info("⏰ Waiting time tracker started")
        
        while self.is_running:
            try:
                if self.is_running:
                    with self.lock:
                        for lane_name in self.lanes.keys():
                            self._update_waiting_times(lane_name)
                
                time.sleep(1)
            except Exception as e:
                logger.error(f"Waiting time update error: {e}")
                time.sleep(1)
    
    def _camera_north_loop(self):
        """Camera 0: North Lane"""
        logger.info("📹 Camera North started")
        self.camera_north = cv2.VideoCapture(0)
        
        if not self.camera_north.isOpened():
            self.camera_north = None
            logger.warning("⚠️ Camera 0 not available")
        
        while self.is_running:
            try:
                if self.camera_north and self.camera_north.isOpened():
                    ret, frame = self.camera_north.read()
                    if ret:
                        frame = cv2.resize(frame, (640, 480))
                        vehicles = self._detect_vehicles(frame)
                        
                        with self.lock:
                            if time.time() - self.last_user_update.get('north', 0) > 5:
                                detected_count = len(vehicles)
                                current_count = len(self.vehicle_queues['north'])
                                
                                if detected_count > current_count:
                                    for _ in range(detected_count - current_count):
                                        self._add_vehicle_to_queue('north')
                                elif detected_count < current_count:
                                    for _ in range(current_count - detected_count):
                                        self._remove_vehicle_from_queue('north')
                        
                        self.current_frame_north = self._draw_detections(
                            frame, vehicles,
                            self.lanes['north']['has_ambulance'],
                            "NORTH LANE - CURRENT SIGNAL"
                        )
                else:
                    import random
                    with self.lock:
                        if time.time() - self.last_user_update.get('north', 0) > 5:
                            self.lanes['north']['vehicles'] = random.randint(0, 8)
                
                time.sleep(0.1)
            except Exception as e:
                logger.error(f"Camera North error: {e}")
                time.sleep(0.1)
    
    def _image_analysis_loop(self):
        """Analyze uploaded image"""
        logger.info("🖼️ Image analysis thread started")
        
        while self.is_running:
            try:
                if self.uploaded_image_path and os.path.exists(self.uploaded_image_path):
                    frame = cv2.imread(self.uploaded_image_path)
                    
                    if frame is not None:
                        frame = cv2.resize(frame, (640, 480))
                        vehicles = self._detect_vehicles(frame)
                        
                        with self.lock:
                            upstream_count = len(vehicles)
                            self.lanes['east']['upstream_vehicles'] = upstream_count
                            
                            if upstream_count >= 15:
                                current_east_vehicles = self.lanes['east']['vehicles']
                                
                                if current_east_vehicles >= 10:
                                    if self.upstream_surge_detected_time is None:
                                        self.upstream_surge_detected_time = time.time()
                                        self.upstream_surge_countdown = 10
                                        logger.warning(f"🔗 UPSTREAM SURGE DETECTED:")
                                        logger.warning(f"   Previous: {upstream_count}v | Current East: {current_east_vehicles}v")
                                else:
                                    if self.upstream_surge_detected_time is not None:
                                        logger.warning(f"⚠️ Upstream cancelled: East has {current_east_vehicles}v")
                                        self.upstream_surge_detected_time = None
                                        self.upstream_surge_countdown = 0
                            else:
                                if self.upstream_surge_detected_time is not None:
                                    logger.info(f"   Upstream dropped below threshold")
                                self.upstream_surge_detected_time = None
                                self.upstream_surge_countdown = 0
                        
                        self.current_frame_east_upstream = self._draw_detections(
                            frame, vehicles,
                            False,
                            f"EAST PREVIOUS SIGNAL - Upstream: {upstream_count}v"
                        )
                
                time.sleep(1)
            except Exception as e:
                logger.error(f"Image analysis error: {e}")
                time.sleep(1)
    
    def _detect_vehicles(self, frame):
        """Detect vehicles using YOLO"""
        vehicles = []
        
        if self.model:
            try:
                results = self.model(frame, verbose=False)
                for r in results:
                    if r.boxes is not None:
                        for box in r.boxes:
                            cls_id = int(box.cls[0])
                            cls_name = self.model.names[cls_id]
                            if cls_name in self.vehicle_classes:
                                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                                conf = float(box.conf[0])
                                vehicles.append({
                                    'type': cls_name,
                                    'confidence': conf,
                                    'bbox': [int(x1), int(y1), int(x2), int(y2)]
                                })
            except Exception as e:
                logger.error(f"Detection error: {e}")
        
        return vehicles
    
    def _draw_detections(self, frame, vehicles, has_ambulance=False, title="CAMERA"):
        """Draw detections on frame"""
        colors = {
            'car': (0, 255, 0),
            'motorcycle': (255, 255, 0),
            'bus': (0, 0, 255),
            'truck': (255, 0, 0)
        }
        
        for vehicle in vehicles:
            x1, y1, x2, y2 = vehicle['bbox']
            v_type = vehicle['type']
            conf = vehicle['confidence']
            color = colors.get(v_type, (0, 255, 0))
            
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 3)
            label = f"{v_type.upper()}: {conf:.2f}"
            (label_w, label_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
            cv2.rectangle(frame, (x1, y1 - label_h - 10), (x1 + label_w + 10, y1), color, -1)
            cv2.putText(frame, label, (x1 + 5, y1 - 5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        overlay_height = 150 if has_ambulance else 120
        cv2.rectangle(frame, (0, 0), (640, overlay_height), (0, 0, 0), -1)
        
        if has_ambulance:
            cv2.rectangle(frame, (0, 0), (640, 40), (0, 0, 255), -1)
            cv2.putText(frame, "AMBULANCE - PRIORITY!", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 3)
            y_offset = 50
        else:
            y_offset = 10
        
        cv2.putText(frame, title, (10, y_offset + 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(frame, f"Vehicles: {len(vehicles)}", (10, y_offset + 55),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        type_counts = {}
        for v in vehicles:
            type_counts[v['type']] = type_counts.get(v['type'], 0) + 1
        
        summary = " | ".join([f"{k.upper()}: {v}" for k, v in type_counts.items()])
        if summary:
            cv2.putText(frame, summary, (10, y_offset + 90),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        
        return frame
    
    def _control_loop(self):
        """Main control loop - FIXED"""
        logger.info("🚦 Control loop started")
        
        while self.is_running:
            try:
                time.sleep(1)
                
                with self.lock:
                    # CRITICAL FIX: Check if current green lane is now empty
                    if self.current_green_lane and not self.in_yellow_phase:
                        if self.lanes[self.current_green_lane]['vehicles'] == 0:
                            logger.info(f"🚫 {self.current_green_lane.upper()} now empty - forcing transition")
                            self._start_yellow_transition()
                            continue
                    
                    if self.upstream_surge_detected_time is not None:
                        elapsed = time.time() - self.upstream_surge_detected_time
                        remaining = max(0, 10 - int(elapsed))
                        self.upstream_surge_countdown = remaining
                    
                    for lane_name, lane in self.lanes.items():
                        if lane['timer'] > 0:
                            lane['timer'] -= 1
                        
                        if lane['signal'] == 'GREEN' and lane['vehicles'] > 0 and not lane.get('has_ambulance', False):
                            if lane['timer'] % 3 == 0 and lane['timer'] != lane['last_clear']:
                                cleared_vehicle = self._remove_vehicle_from_queue(lane_name)
                                if cleared_vehicle:
                                    wait_time = cleared_vehicle.waiting_time
                                    self.statistics['total_waiting_time'] += wait_time
                                    self.statistics['vehicles_cleared'] += 1
                                    
                                    if self.use_awt_algorithm:
                                        self.statistics['awt_total_wait_time'] += wait_time
                                        self.statistics['awt_vehicles_cleared'] += 1
                                    else:
                                        self.statistics['vac_total_wait_time'] += wait_time
                                        self.statistics['vac_vehicles_cleared'] += 1
                                    
                                    lane['last_clear'] = lane['timer']
                    
                    if self.in_yellow_phase:
                        if self.yellow_countdown > 0:
                            self.yellow_countdown -= 1
                        else:
                            self._switch_to_highest_priority_lane()
                        self._update_statistics()
                        continue
                    
                    ambulance_lane = self._check_ambulance()
                    if ambulance_lane and ambulance_lane != self.current_green_lane:
                        logger.critical(f"🚑 AMBULANCE: {ambulance_lane.upper()}")
                        if self.upstream_surge_detected_time is not None:
                            self.upstream_surge_detected_time = None
                            self.upstream_surge_countdown = 0
                        self._do_ambulance_switch(ambulance_lane)
                        continue
                    
                    emerg = self._check_emergency()
                    if emerg and emerg != self.current_green_lane:
                        logger.critical(f"🚨 EMERGENCY: {emerg.upper()}")
                        if self.upstream_surge_detected_time is not None:
                            self.upstream_surge_detected_time = None
                            self.upstream_surge_countdown = 0
                        self._do_emergency_switch(emerg)
                        continue
                    
                    if self.upstream_surge_detected_time is not None:
                        elapsed = time.time() - self.upstream_surge_detected_time
                        
                        if self.lanes['east']['vehicles'] < 10:
                            self.upstream_surge_detected_time = None
                            self.upstream_surge_countdown = 0
                        elif elapsed >= 10:
                            if self.lanes['east']['upstream_vehicles'] >= 15:
                                if self.current_green_lane != 'east':
                                    logger.critical(f"🔗 UPSTREAM SURGE ACTIVATED!")
                                    self._do_upstream_surge_switch()
                                    continue
                            else:
                                self.upstream_surge_detected_time = None
                                self.upstream_surge_countdown = 0
                    
                    if self.current_green_lane:
                        if self.lanes[self.current_green_lane]['timer'] == 0:
                            logger.info(f"✅ {self.current_green_lane.upper()} complete")
                            self._start_yellow_transition()
                    
                    self._update_statistics()
                
            except Exception as e:
                logger.error(f"❌ Error: {e}")
                import traceback
                traceback.print_exc()
                time.sleep(1)
    
    def _check_ambulance(self):
        for name, lane in self.lanes.items():
            if lane.get('has_ambulance', False):
                return name
        return None
    
    def _do_ambulance_switch(self, ambulance_lane):
        self.statistics['ambulance_activations'] += 1
        self._pending_ambulance_lane = ambulance_lane
        
        self.upstream_surge_detected_time = None
        self.upstream_surge_countdown = 0
        
        if self.current_green_lane and self.current_green_lane != ambulance_lane:
            self.lanes[self.current_green_lane]['signal'] = 'YELLOW'
            self.lanes[self.current_green_lane]['timer'] = 3
        
        self.in_yellow_phase = True
        self.yellow_countdown = 3
        self.current_green_lane = ambulance_lane
    
    def _check_emergency(self):
        for name, lane in self.lanes.items():
            if lane['vehicles'] >= 18:
                return name
        return None
    
    def _do_emergency_switch(self, emerg_lane):
        self.statistics['emergency_activations'] += 1
        
        self.upstream_surge_detected_time = None
        self.upstream_surge_countdown = 0
        
        if self.current_green_lane:
            self.lanes[self.current_green_lane]['signal'] = 'YELLOW'
            self.lanes[self.current_green_lane]['timer'] = 3
        
        self.in_yellow_phase = True
        self.yellow_countdown = 3
        self.current_green_lane = emerg_lane
    
    def _do_upstream_surge_switch(self):
        logger.critical("🔗 UPSTREAM SURGE ACTIVATION")
        self.statistics['upstream_surge_activations'] += 1
        self._pending_upstream_surge = True
        
        self.upstream_surge_detected_time = None
        self.upstream_surge_countdown = 0
        
        if self.current_green_lane and self.current_green_lane != 'east':
            self.lanes[self.current_green_lane]['signal'] = 'YELLOW'
            self.lanes[self.current_green_lane]['timer'] = 3
        
        self.in_yellow_phase = True
        self.yellow_countdown = 3
        self.current_green_lane = 'east'
    
    def _start_yellow_transition(self):
        if self.current_green_lane:
            logger.info(f"🟡 Yellow: {self.current_green_lane.upper()}")
            self.lanes[self.current_green_lane]['signal'] = 'YELLOW'
            self.lanes[self.current_green_lane]['timer'] = 3
            self.in_yellow_phase = True
            self.yellow_countdown = 3
    
    def _get_highest_priority_lane(self):
        """Get highest priority lane using selected algorithm - FIXED"""
        algo = self.awt_algorithm if self.use_awt_algorithm else self.vac_algorithm
        
        for name, lane in self.lanes.items():
            if lane['vehicles'] >= 18:
                return name, 'EMERGENCY'
        
        if self.lanes['east']['upstream_vehicles'] >= 15:
            if self.lanes['east']['vehicles'] >= 10:
                if self.upstream_surge_detected_time is not None:
                    elapsed = time.time() - self.upstream_surge_detected_time
                    if elapsed >= 10:
                        return 'east', 'UPSTREAM_SURGE'
        
        starved_lanes = {
            name: self.cycles_since_service[name]
            for name, lane in self.lanes.items()
            if self.cycles_since_service[name] >= self.starvation_threshold and lane['vehicles'] > 0
        }
        
        if starved_lanes:
            max_wait = max(starved_lanes.values())
            longest_waiting = [name for name, cycles in starved_lanes.items() if cycles == max_wait]
            
            if len(longest_waiting) > 1:
                vehicles_in_starved = {name: self.lanes[name]['vehicles'] for name in longest_waiting}
                max_vehicles_starved = max(vehicles_in_starved.values())
                longest_waiting = [name for name, v in vehicles_in_starved.items() if v == max_vehicles_starved]
            
            chosen = sorted(longest_waiting)[0]
            logger.warning(f"⚠️ ANTI-STARVATION: {chosen.upper()}")
            return chosen, 'ANTI_STARVATION'
        
        # FIXED: Only consider lanes with vehicles > 0
        candidates = {}
        for name, lane in self.lanes.items():
            if lane['vehicles'] > 0:
                score = algo.calculate_priority_score(
                    lane['vehicles'],
                    lane['avg_waiting_time'],
                    is_first_cycle=self.is_first_cycle
                )
                candidates[name] = {
                    'score': score,
                    'vehicles': lane['vehicles'],
                    'avg_wait': lane['avg_waiting_time'],
                    'urgency': lane['urgency']
                }
        
        # FIXED: Better fallback handling
        if not candidates:
            for name, lane in self.lanes.items():
                if lane['vehicles'] > 0:
                    return name, 'FALLBACK'
            return 'east', 'SYSTEM_IDLE'
        
        max_score = max(c['score'] for c in candidates.values())
        top_lanes = [name for name, data in candidates.items() if data['score'] == max_score]
        
        if len(top_lanes) > 1:
            wait_times = {name: candidates[name]['avg_wait'] for name in top_lanes}
            max_wait = max(wait_times.values())
            top_lanes = [name for name, wait in wait_times.items() if wait == max_wait]
            
            if len(top_lanes) > 1:
                chosen = sorted(top_lanes)[0]
                return chosen, 'TIE_BREAK'
        
        chosen = top_lanes[0]
        data = candidates[chosen]
        
        if self.use_awt_algorithm:
            if data['avg_wait'] >= 60:
                self.statistics['waiting_time_priorities'] += 1
                return chosen, 'CRITICAL_WAIT_TIME'
            elif data['avg_wait'] >= 40:
                self.statistics['waiting_time_priorities'] += 1
                return chosen, 'HIGH_WAIT_TIME'
        
        return chosen, 'COMBINED_PRIORITY' if self.use_awt_algorithm else 'VAC_PRIORITY'
    
    def _switch_to_highest_priority_lane(self):
        """Switch to highest priority lane - OPTIMIZED"""
        has_pending_ambulance = hasattr(self, '_pending_ambulance_lane') and self._pending_ambulance_lane
        has_pending_surge = hasattr(self, '_pending_upstream_surge') and self._pending_upstream_surge
        
        if has_pending_ambulance:
            next_lane = self._pending_ambulance_lane
            reason = 'AMBULANCE_OVERRIDE'
            self._pending_ambulance_lane = None
            upstream_surge = False
        elif has_pending_surge:
            next_lane = 'east'
            reason = 'UPSTREAM_SURGE'
            self._pending_upstream_surge = False
            upstream_surge = True
        else:
            next_lane, reason = self._get_highest_priority_lane()
            upstream_surge = (reason == 'UPSTREAM_SURGE')
        
        algo_name = "AWT" if self.use_awt_algorithm else "VAC"
        logger.info("\n" + "="*70)
        logger.info(f"🎯 ALGORITHM: {algo_name} | SELECTION: {next_lane.upper()}")
        logger.info("="*70)
        
        for lane_name in self.lanes:
            if lane_name == next_lane:
                self.cycles_since_service[lane_name] = 0
            else:
                if self.lanes[lane_name]['vehicles'] > 0:
                    self.cycles_since_service[lane_name] += 1
        
        logger.info("📊 Priority Queue:")
        
        algo = self.awt_algorithm if self.use_awt_algorithm else self.vac_algorithm
        lane_scores = []
        for name, lane in self.lanes.items():
            if lane['vehicles'] > 0:
                score = algo.calculate_priority_score(
                    lane['vehicles'],
                    lane['avg_waiting_time'],
                    is_first_cycle=self.is_first_cycle
                )
                lane_scores.append({
                    'name': name,
                    'score': score,
                    'vehicles': lane['vehicles'],
                    'avg_wait': lane['avg_waiting_time'],
                    'max_wait': lane['max_waiting_time']
                })
        
        lane_scores.sort(key=lambda x: x['score'], reverse=True)
        
        for i, data in enumerate(lane_scores, 1):
            emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "  "
            status = "← SELECTED" if data['name'] == next_lane else ""
            
            logger.info(
                f"{emoji} {data['name'].upper()}: "
                f"{data['vehicles']}v | "
                f"Avg:{data['avg_wait']:.1f}s Max:{data['max_wait']:.1f}s | "
                f"Score:{data['score']:.2f} {status}"
            )
        
        logger.info(f"🎯 Reason: {reason}")
        logger.info("="*70)
        
        vehicle_count = self.lanes[next_lane]['vehicles']
        avg_wait = self.lanes[next_lane]['avg_waiting_time']
        has_ambulance = self.lanes[next_lane].get('has_ambulance', False)
        
        green_time, rules, priority = algo.calculate_green_time(
            vehicle_count, avg_wait, has_ambulance, upstream_surge
        )
        
        # FIXED: Skip empty lanes
        if vehicle_count == 0 and not has_ambulance and not upstream_surge:
            logger.warning(f"⚠️ {next_lane.upper()} is empty, finding alternative...")
            # Find next non-empty lane
            for name, lane in self.lanes.items():
                if lane['vehicles'] > 0:
                    next_lane = name
                    vehicle_count = lane['vehicles']
                    avg_wait = lane['avg_waiting_time']
                    green_time, rules, priority = algo.calculate_green_time(
                        vehicle_count, avg_wait, False, False
                    )
                    break
        
        self.current_green_lane = next_lane
        self.last_served_lane = next_lane
        
        self.lanes[next_lane]['signal'] = 'GREEN'
        self.lanes[next_lane]['timer'] = green_time
        self.lanes[next_lane]['last_clear'] = green_time
        
        for name in self.lanes:
            if name != next_lane:
                self.lanes[name]['signal'] = 'RED'
                self.lanes[name]['timer'] = green_time + 10
        
        self.in_yellow_phase = False
        self.statistics['cycles_completed'] += 1
        
        if self.use_awt_algorithm:
            self.statistics['awt_cycles'] += 1
        else:
            self.statistics['vac_cycles'] += 1
        
        if self.is_first_cycle:
            self.is_first_cycle = False
            logger.info("✅ First cycle complete")
        
        logger.info(f"✅ {next_lane.upper()}: {vehicle_count}v, Avg Wait: {avg_wait:.1f}s → {green_time}s {priority}")
        logger.info("="*70 + "\n")
        
        if has_ambulance:
            self.lanes[next_lane]['has_ambulance'] = False
        
        self.signal_logic = {
            'decision': f"{next_lane.upper()} ({vehicle_count}v, {avg_wait:.1f}s wait) - {reason}",
            'action': f"{next_lane.upper()}: {green_time}s GREEN",
            'priority': priority,
            'reason': ' | '.join(rules),
            'rules_applied': rules,
            'algorithm_used': algo_name
        }
    
    # CONTINUATION OF _update_statistics method
    
    def _update_statistics(self):
        """Update system statistics"""
        try:
            total = sum(l['vehicles'] for l in self.lanes.values())
            
            all_waits = [l['avg_waiting_time'] for l in self.lanes.values() if l['vehicles'] > 0]
            system_avg_wait = np.mean(all_waits) if all_waits else 0
            
            if len(all_waits) > 1:
                variance = np.var(all_waits)
            else:
                variance = 0
            
            if system_avg_wait > 0:
                eff = max(50, min(98, 100 - (system_avg_wait / 2)))
            else:
                eff = 95
            
            self.statistics.update({
                'total_vehicles_processed': total,
                'avg_wait_time': round(system_avg_wait, 1),
                'system_efficiency': round(eff, 1),
                'waiting_time_variance': round(variance, 2)
            })
            
            if self.statistics['vac_vehicles_cleared'] > 0:
                self.statistics['vac_avg_wait_time'] = round(
                    self.statistics['vac_total_wait_time'] / self.statistics['vac_vehicles_cleared'], 1
                )
            
            if self.statistics['awt_vehicles_cleared'] > 0:
                self.statistics['awt_avg_wait_time'] = round(
                    self.statistics['awt_total_wait_time'] / self.statistics['awt_vehicles_cleared'], 1
                )
            
            if self.statistics['vac_avg_wait_time'] > 0 and self.statistics['awt_avg_wait_time'] > 0:
                self.statistics['wait_time_improvement'] = round(
                    ((self.statistics['vac_avg_wait_time'] - self.statistics['awt_avg_wait_time']) / 
                     self.statistics['vac_avg_wait_time']) * 100, 1
                )
            
        except Exception as e:
            logger.error(f"Statistics update error: {e}")
    
    def _broadcast_loop(self):
        """Broadcast updates to frontend"""
        while self.is_running:
            try:
                with self.lock:
                    phase_name = f"{self.current_green_lane.upper()} GREEN" if self.current_green_lane else "INIT"
                    all_empty = all(l['vehicles'] == 0 for l in self.lanes.values())
                    
                    data = {
                        'timestamp': datetime.now().isoformat(),
                        'is_running': self.is_running,
                        'current_phase': phase_name,
                        'all_empty': all_empty,
                        'upstream_countdown': self.upstream_surge_countdown,
                        'is_first_cycle': self.is_first_cycle,
                        'use_awt_algorithm': self.use_awt_algorithm,
                        'lanes': {
                            name: {
                                'type': 'REAL_CAMERA' if name == 'north' else 'SIMULATED',
                                'vehicles': info['vehicles'],
                                'speed': info['speed'],
                                'signal': 'RED' if all_empty else info['signal'],
                                'timer': info['timer'],
                                'has_ambulance': info.get('has_ambulance', False),
                                'upstream_vehicles': info.get('upstream_vehicles', 0) if name == 'east' else 0,
                                'avg_waiting_time': info['avg_waiting_time'],
                                'max_waiting_time': info['max_waiting_time'],
                                'urgency': info['urgency'],
                                'heatmap_color': info['heatmap_color'],
                                'heatmap_label': info['heatmap_label']
                            }
                            for name, info in self.lanes.items()
                        },
                        'signal_logic': self.signal_logic,
                        'statistics': self.statistics
                    }
                
                socketio.emit('traffic_update', data)
                time.sleep(0.5)
            except Exception as e:
                logger.error(f"Broadcast error: {e}")
                time.sleep(0.5)
    
    def upload_upstream_image(self, file_path):
        """Set uploaded image for upstream analysis"""
        with self.lock:
            self.uploaded_image_path = file_path
            logger.info(f"🖼️ Uploaded image set: {file_path}")
        return True
    
    def update_lane(self, lane, vehicles=None, speed=None):
        """Update lane parameters"""
        with self.lock:
            if vehicles is not None:
                new_count = int(vehicles)
                current_count = len(self.vehicle_queues[lane])
                
                current_time = time.time()
                
                if new_count > current_count:
                    for _ in range(new_count - current_count):
                        vehicle = Vehicle(self.next_vehicle_id, lane, current_time)
                        self.vehicle_queues[lane].append(vehicle)
                        self.next_vehicle_id += 1
                        self.lanes[lane]['vehicles'] = len(self.vehicle_queues[lane])
                elif new_count < current_count:
                    for _ in range(current_count - new_count):
                        self._remove_vehicle_from_queue(lane)
                
                self.last_user_update[lane] = time.time()
            
            if speed is not None:
                self.lanes[lane]['speed'] = int(speed)
        return True
    
    def test_ambulance(self, lane):
        """Test ambulance override"""
        with self.lock:
            self.lanes[lane]['has_ambulance'] = True
            logger.critical(f"🚑 TEST: {lane.upper()}")
        return True
    
    def get_state(self):
        """Get current system state"""
        with self.lock:
            phase_name = f"{self.current_green_lane.upper()} GREEN" if self.current_green_lane else "INIT"
            all_empty = all(l['vehicles'] == 0 for l in self.lanes.values())
            
            return {
                'is_running': self.is_running,
                'current_phase': phase_name,
                'all_empty': all_empty,
                'upstream_countdown': self.upstream_surge_countdown,
                'is_first_cycle': self.is_first_cycle,
                'use_awt_algorithm': self.use_awt_algorithm,
                'lanes': {n: dict(l) for n, l in self.lanes.items()},
                'signal_logic': self.signal_logic,
                'statistics': self.statistics
            }


# Initialize system
system = PriorityTrafficSystem()


# Flask Routes
@app.route('/')
def index():
    return render_template('integrated_dashboard.html')


@app.route('/api/start', methods=['POST'])
def api_start():
    """Start the traffic system"""
    return jsonify({'success': system.start()})


@app.route('/api/stop', methods=['POST'])
def api_stop():
    """Stop the traffic system"""
    return jsonify({'success': system.stop()})


@app.route('/api/toggle_algorithm', methods=['POST'])
def api_toggle_algorithm():
    """Toggle between VAC and AWT algorithms"""
    use_awt = system.toggle_algorithm()
    return jsonify({
        'success': True,
        'use_awt_algorithm': use_awt,
        'algorithm_name': 'AWT (Adaptive Waiting Time)' if use_awt else 'VAC (Vehicle Actuated Control)'
    })


@app.route('/api/update_lane', methods=['POST'])
def api_update():
    """Update lane vehicle count or speed"""
    data = request.get_json()
    return jsonify({'success': system.update_lane(data.get('lane'), data.get('vehicles'), data.get('speed'))})


@app.route('/api/test_ambulance', methods=['POST'])
def api_test_ambulance():
    """Test ambulance priority override"""
    data = request.get_json()
    lane = data.get('lane', 'north')
    return jsonify({'success': system.test_ambulance(lane)})


@app.route('/api/upload_upstream', methods=['POST'])
def api_upload_upstream():
    """Upload image for upstream detection"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': 'No file provided'})
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No file selected'})
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"upstream_{timestamp}_{filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
            file.save(filepath)
            system.upload_upstream_image(filepath)
            
            logger.info(f"✅ Image uploaded: {filename}")
            return jsonify({
                'success': True,
                'message': f'Image uploaded: {filename}',
                'filename': filename
            })
        else:
            return jsonify({'success': False, 'message': 'Invalid file type'})
            
    except Exception as e:
        logger.error(f"Upload error: {e}")
        return jsonify({'success': False, 'message': str(e)})


@app.route('/api/state')
def api_state():
    """Get current system state"""
    return jsonify(system.get_state())


@app.route('/video_feed_north')
def video_feed_north():
    """Video feed for North lane camera"""
    def generate():
        while True:
            try:
                if system.current_frame_north is not None:
                    ret, buffer = cv2.imencode('.jpg', system.current_frame_north, [cv2.IMWRITE_JPEG_QUALITY, 70])
                    if ret:
                        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
                time.sleep(0.1)
            except:
                time.sleep(0.1)
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/video_feed_east_upstream')
def video_feed_east_upstream():
    """Video feed for East upstream image"""
    def generate():
        while True:
            try:
                if system.current_frame_east_upstream is not None:
                    ret, buffer = cv2.imencode('.jpg', system.current_frame_east_upstream, [cv2.IMWRITE_JPEG_QUALITY, 70])
                    if ret:
                        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
                time.sleep(0.1)
            except:
                time.sleep(0.1)
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')


@socketio.on('connect')
def on_connect():
    """Handle client connection"""
    socketio.emit('initial_state', system.get_state())


@socketio.on('disconnect')
def on_disconnect():
    """Handle client disconnection"""
    pass


if __name__ == '__main__':
    print("\n" + "="*70)
    print("🚦 VisionFlow v5.1 - FIXED VERSION")
    print("="*70)
    print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"👤 User: Akashy630")
    print("="*70)
    print("✅ KEY FIXES APPLIED:")
    print("   • Proper timer calculations (4v × 3s = 12s)")
    print("   • Immediate red when lane reaches 0 vehicles")
    print("   • Faster AWT switching (optimized weights)")
    print("   • Better waiting time boosts (20s/12s/7s)")
    print("   • Empty lanes are skipped automatically")
    print("="*70)
    print("🔄 DUAL ALGORITHM SYSTEM:")
    print("   • VAC: Traditional vehicle count based")
    print("   • AWT: Adaptive waiting time optimization")
    print("   • Real-time toggle between algorithms")
    print("   • Comparison metrics showing AWT superiority")
    print("="*70)
    print("🌐 http://localhost:5000")
    print("="*70 + "\n")
    
    try:
        socketio.run(app, host='0.0.0.0', port=5000, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        system.stop()